let gl, program;
let vertexCount = 36;
let modelViewMatrix;
let projectionMatrix;

let eye = [0, 0, 0.1];
let at = [0, 0, 0];
let up = [0, 1, 0];

let left = -2;
let right = 2;
let bottom = -2;
let ytop = 2;

let near = 0.1;
let far = 10;
let fovy = 45; // field of view in degrees
let aspect = 4/3; // gl.canvas.width / gl.canvas.height

let vertices = [
    -1, -1, 1,
    -1, 1, 1,
    1, 1, 1,
    1, -1, 1,
    -1, -1, -1,
    -1, 1, -1,
    1, 1, -1,
    1, -1, -1,
];
let vertices2 = [ 3, -1, -1, 3, 1, -1, 5, 1, -1, 5, -1, -1, 3, -1, -3, 3, 1, -3, 5, 1, -3, 5, -1, -3, ];

let isOrthographic = 1;

onload = () => {
    let canvas = document.getElementById("webgl-canvas");
    
    gl = WebGLUtils.setupWebGL(canvas);
    if (!gl) {
        alert('No webgl for you');
        return;
    }

    program = initShaders(gl, 'vertex-shader', 'fragment-shader');
    gl.useProgram(program);

    gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);

    gl.enable(gl.DEPTH_TEST);

    gl.clearColor(0, 0, 0, 0.5);


    let indices = [
        0, 3, 1,
        1, 3, 2,
        4, 7, 5,
        5, 7, 6,
        3, 7, 2,
        2, 7, 6,
        4, 0, 5,
        5, 0, 1,
        1, 2, 5,
        5, 2, 6,
        0, 3, 4,
        4, 3, 7,
    ];

    let colors = [
        0, 0, 0,
        0, 0, 1,
        0, 1, 0,
        0, 1, 1,
        1, 0, 0,
        1, 0, 1,
        1, 1, 0,
        1, 1, 1,
    ];

    // You should get rid of the line below eventually
    // vertices = scale(0.5, vertices); 

    let vBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);

    let vPosition = gl.getAttribLocation(program, 'vPosition');
    gl.vertexAttribPointer(vPosition,3,gl.FLOAT,false,0,0);
    gl.enableVertexAttribArray(vPosition);

    let iBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, iBuffer);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint8Array(indices), gl.STATIC_DRAW);

    let cBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, cBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(colors), gl.STATIC_DRAW);

    let vColor = gl.getAttribLocation(program, 'vColor');
    gl.vertexAttribPointer(vColor,3,gl.FLOAT,false,0,0);
    gl.enableVertexAttribArray(vColor);

    modelViewMatrix = gl.getUniformLocation(program, 'modelViewMatrix');
    projectionMatrix = gl.getUniformLocation(program, 'projectionMatrix');
    document.addEventListener('keydown', handleKeyDown);


    render();
};

function generateCube(vertices) { 
    let vBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);

    let vPosition = gl.getAttribLocation(program, 'vPosition');
    gl.vertexAttribPointer(vPosition,3,gl.FLOAT,false,0,0);
    gl.enableVertexAttribArray(vPosition);
    gl.drawElements(gl.TRIANGLES, vertexCount, gl.UNSIGNED_BYTE, 0);
}

function handleKeyDown(event) {
    switch (event.key) {
        case 'T':
            // Top-side view:
            eye = [0, 1, 0];
            at = [0, 0, 0];
            up = [0, 0, -1];
            break;
        case 'L':
            // Left-side view:
            eye = [-1, 0, 0];
            at = [0, 0, 0];
            up = [0, 1, 0];
            break;
        case 'F':
            // Front-side view:
            eye = [0, 0, 1];
            at = [0, 0, 0];
            up = [1, 0, 0];
            break;
        case 'D':
            // Rotate clockwise:
            rotateCamera(0.5); 
            break;
        case 'A':
            // Rotate counter-clockwise:
            rotateCamera(-0.5); 
            break;
            // Isometric View:
        case 'I':
            eye = [2, 2, 2];
            at = [0, 0, 0];
            up = [0, 1, 0];
            break;
        case 'W':
            // Zoom in
            if(isOrthographic==0){
                eye[0] = eye[0] * 0.8;
                eye[1] = eye[1] * 0.8;
                eye[2] = eye[2] * 0.8;
            }
            else{
                ytop = ytop - 0.05;
                bottom = bottom + 0.05;
                left = left + 0.05;
                right = right - 0.05;
            }
            break;
        case 'S':
            // Zoom out
            if(isOrthographic==0){
                eye[0] = eye[0] * 1.2;
                eye[1] = eye[1] * 1.2;
                eye[2] = eye[2] * 1.2;
            }
            else{
                ytop = ytop + 0.05;
                bottom = bottom - 0.05;
                left = left - 0.05;
                right = right + 0.05;
            }
            break;
            case "O":
                isOrthographic = 1;
                break;
            case "P":
                isOrthographic = 0;
                break;
           
    }
    render();
}


function rotateCamera(theta) {
    
    if (eye[0] === 0 && eye[1] === 1 && eye[2] === 0) {
        // Top-side view
        up = [
            Math.cos(theta) * up[0] + Math.sin(theta) * up[2],
            up[1],
            -Math.sin(theta) * up[0] + Math.cos(theta) * up[2]
        ];
    } else if (eye[0] === -1 && eye[1] === 0 && eye[2] === 0) {
        // Left-side view
        up = [
            up[0],
            Math.cos(theta) * up[1] + Math.sin(theta) * up[2],
            -Math.sin(theta) * up[1] + Math.cos(theta) * up[2]
        ];
    } else {
        // Front-side view 
        up = [
            Math.cos(theta) * up[0] - Math.sin(theta) * up[1],
            Math.sin(theta) * up[0] + Math.cos(theta) * up[1],
            up[2]
        ];
    }
}

function render() { 
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    if(isOrthographic==1){
        pro_mat = ortho(left, right, bottom, ytop, -100, 100);
        gl.uniformMatrix4fv(projectionMatrix, false, flatten(pro_mat));
        mvm = lookAt(eye, at, up);
        gl.uniformMatrix4fv(modelViewMatrix, false,flatten(mvm));
        
        generateCube(vertices);
        generateCube(vertices2);
    }
    else{
        let pro_mat_pers = perspective(fovy, aspect, 0.1, 100);
        gl.uniformMatrix4fv(projectionMatrix, false, flatten(pro_mat_pers));
        mvm = lookAt(eye, at, up);
        gl.uniformMatrix4fv(modelViewMatrix, false,flatten(mvm));

        generateCube(vertices);
        generateCube(vertices2);
    }

    gl.drawElements(gl.TRIANGLES, vertexCount, gl.UNSIGNED_BYTE, 0);
    

    requestAnimationFrame(render);
}